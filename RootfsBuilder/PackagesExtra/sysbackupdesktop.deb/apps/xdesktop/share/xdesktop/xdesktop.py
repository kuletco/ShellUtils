#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Copyright (C) xinli 2011 <xinli@starsoftcomm.com>
# 
# datarescue is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# datarescue is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.

import os, sys, ConfigParser, locale, gettext
from os.path import join, dirname, abspath, exists
import ConfigParser
import pygtk
#import glib
import gtkdialogs
pygtk.require('2.0')
try:
	import gtk
	import gobject
except:
	print("error: import 'gtk' failed!")
	sys.exit(1)
#import commands

APP_NAME = "ssc_ccm"

import ssc_message_window
from ssc_widget import *

#PATH = '/usr/share/recovery_manager/'
#PATH = '/opt/plugin_mgr/'
APPNAME = 'xdesktop'
APP_DIR = dirname(abspath(__file__))
PATH = APP_DIR + '/'
gtkrc_file = PATH+'gtk_font_rc'
gladefile = PATH+'desktop.xml'
backgroundrun = ' > /dev/null 2>&1'
program1 = 'emelfm2 -1 /WINDOWS -2 /storage --config=/usr/share/emelfm2'
#program1 = '/opt/data_rescue/bin/data_rescue --config=/opt/data_rescue/share/emelfm2 -1 /WINDOWS -2 /WINDOWS'
program2 = 'sysbackup'
program3 = 'userhelp'
image_background_file = PATH+'ssc_msp_ccm_bg.png'
frame_image_file1 = PATH+'res/frame_date_save.png'
frame_image_file2 = PATH+'res/frame_recovery.png'
frame_image_file3 = PATH+'res/frame_help.png'
message0 = ''
message1 = '系统发生故障导致windows操作系统崩溃情况下，帮助您拯救操作系统盘中重要数据和文件，及时避免无法挽回的损失。'
message2 = '病毒损害，系统文件丢失等可能会造成系统崩溃，系统恢复可以帮您恢复系统到健康状态。建议您培养及时备份系统的良好习惯。'
message4 = '电脑不会用 电脑不好使 电脑不能用 别担心 有惠普e管家 我们来解决！24小时全天候给你电脑保驾护航 \n\n\
你在电脑的使用过程中遇到任何问题，只需轻轻一点，在线专家将第一时间帮你解决！'
message3 = '帮助系统'
###############
##global data
###############

x = 815
y = 512

gtk.rc_parse(gtkrc_file)

class MainWindow:

	def __init__(self):
		builder = gtk.Builder()
		builder.add_from_file(gladefile)

		self.main_window = builder.get_object("main_window")
		self.alignment = builder.get_object("alignment1")
		self.button1 = builder.get_object("button1")
		self.button2 = builder.get_object("button2")
		self.button3 = builder.get_object("button3")
#		self.button4 = builder.get_object("button4")
		self.button_halt = builder.get_object("button_halt")
		self.button_reboot = builder.get_object("button_reboot")
		self.label_message = builder.get_object("label_message")
		self.label_title1 = builder.get_object("label_title1")
		self.label_title2 = builder.get_object("label_title2")
		self.label_title3 = builder.get_object("label_title3")
		self.image_frame = builder.get_object("image_frame")
		self.label_halt = builder.get_object("label_halt")
		self.label_reboot = builder.get_object("label_reboot")
		
		self.program_button = [self.button1, self.button2, self.button3]
		self.program_name = [program1, program2, program3]

		builder.connect_signals(self)

		self.button1.set_name('datasave_button')
		self.button2.set_name('recovery_button')
		self.button3.set_name('help_button')
#		self.button4.set_name('button_app4.app_button')
		self.button_halt.set_name('button_halt.operation_button')
		self.button_reboot.set_name('button_reboot.operation_button')
		self.label_title1.set_name('label_title1.label_title')
		self.label_title2.set_name('label_title2.label_title')
		self.label_title3.set_name('label_title3.label_title')
		self.label_message.set_name('label_message.label_message')
		self.label_halt.set_name('label_halt.label_operation')
		self.label_reboot.set_name('label_reboot.label_operation')



		self.button1.connect('clicked', self.button_myapp1_launcher)
		self.button2.connect('clicked', self.button_myapp2_launcher)
		self.button3.connect('clicked', self.button_myapp3_launcher)
#		self.button4.connect('clicked', self.button_myapp4_launcher)
		self.button_halt.connect('clicked', self.button_halt_launcher)
		self.button_reboot.connect('clicked', self.button_reboot_launcher)

		self.button1.connect("enter", self.change_cursor_to_hand ,self.button1, 1)
		self.button1.connect("leave", self.change_cursor_to_normal ,self.button1, 1)
		self.button2.connect("enter", self.change_cursor_to_hand ,self.button2, 2)
		self.button2.connect("leave", self.change_cursor_to_normal ,self.button2, 2)
		self.button3.connect("enter", self.change_cursor_to_hand ,self.button3, 3)
		self.button3.connect("leave", self.change_cursor_to_normal ,self.button3, 3)
#		self.button4.connect("enter", self.change_cursor_to_hand ,self.button4, 4)
#		self.button4.connect("leave", self.change_cursor_to_normal ,self.button4, 4)
		self.button_halt.connect("enter", self.change_cursor_to_hand ,self.button_halt, 5)
		self.button_halt.connect("leave", self.change_cursor_to_normal,self.button_halt, 5)
		self.button_reboot.connect("enter", self.change_cursor_to_hand,self.button_reboot, 6)
		self.button_reboot.connect("leave", self.change_cursor_to_normal,self.button_reboot, 6)



#		self.label_message.set_size_request(650, -1)

		pixbuf = gtk.gdk.pixbuf_new_from_file(image_background_file)
#		pixbuf = pixbuf.scale_simple(x, y, gtk.gdk.INTERP_HYPER)
		pixmap, mask = pixbuf.render_pixmap_and_mask()

#		self.main_window.resize(x, y)
		self.main_window.set_position(gtk.WIN_POS_CENTER_ALWAYS)
		self.main_window.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DESKTOP)
		self.main_window.set_decorated(False)
		self.main_window.set_resizable(False)

		self.main_window.set_app_paintable(True)
		self.main_window.realize()
		
		self.main_window.window.set_back_pixmap(pixmap, False)

#		self.label_message.set_text(message0)
#		self.check_install_program()

		self.main_window.show_now()
#		while gtk.events_pending():
#			gtk.main_iteration(True)

#		self.main_window.resize(x, y)
#		self.main_window.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_DESKTOP)

#		gtk.main()

	def check_install_program(self):
		for i in range(3):
			if not os.path.isfile(self.program_name[i]):
				self.program_button[i].hide()

	def change_cursor_to_hand(self, widget, button_widget, whichbutton):
#		self.main_window.hide()
		button_widget.window.set_cursor(gtk.gdk.Cursor(gtk.gdk.HAND2))
#		self.main_window.show()
		if whichbutton == 1:
			self.label_message.set_text(message1)
			self.image_frame.set_from_file(frame_image_file1)
		elif whichbutton == 2:
			self.label_message.set_text(message2)
			self.image_frame.set_from_file(frame_image_file2)
		elif whichbutton == 3:
			self.label_message.set_text(message3)
			self.image_frame.set_from_file(frame_image_file3)
		elif whichbutton == 4:
			self.label_message.set_text(message4)
		else:
			pass


	def change_cursor_to_normal(self, widget, button_widget, whichbutton):
		button_widget.window.set_cursor(None)
#		self.label_message.set_text('')
		self.label_message.set_text(message0)
		self.image_frame.set_from_file(None)

	def button_myapp1_launcher(self, widget):
                self.main_window.hide()
		while gtk.events_pending():
			gtk.main_iteration(True)
		os.system(program1+backgroundrun)
                self.main_window.show()
		while gtk.events_pending():
			gtk.main_iteration(True)

	def button_myapp2_launcher(self, widget):
                self.main_window.hide()
		while gtk.events_pending():
			gtk.main_iteration(True)
		os.system(program2+backgroundrun)
                self.main_window.show()
		while gtk.events_pending():
			gtk.main_iteration(True)

	def button_myapp3_launcher(self, widget):
                self.main_window.hide()
		while gtk.events_pending():
			gtk.main_iteration(True)
		os.system(program3+backgroundrun)
                self.main_window.show()
		while gtk.events_pending():
			gtk.main_iteration(True)

	def button_myapp4_launcher(self, widget):
		os.system("/opt/z_help/client"+backgroundrun)

	def button_halt_launcher(self, widget):
#		tt = gtkdialogs.yesno("OK ?")
		win = ssc_message_window.ssc_message_window(None, 0, None, gtk.BUTTONS_YES_NO, _("是否确定关闭系统？"))
		win.run()
		if win.response_id == gtk.RESPONSE_YES:
			os.system("poweroff")
		return

	def button_reboot_launcher(self, widget):
		win = ssc_message_window.ssc_message_window(None, 0, None, gtk.BUTTONS_YES_NO, _("是否确定重启系统？"))
		win.run()
		if win.response_id == gtk.RESPONSE_YES:
			os.system("reboot")
		return

	def on_window_destroy(self, widget, data=None):
		gtk.main_quit()


if __name__ == '__main__':
	# gettext.bindtextdomain(APP_NAME, "/usr/local/share/locale/")
	#os.system("cp /mnt/hidpart/StarOS/scripts/shell/mount_windows_partitions /root/utils")
	#os.system("umount /WINDOWS/*")
#	os.system("touch /tmp/startup_splash")
#	os.system("/opt/plugin_mgr/decrypt_active.sh")
#	os.system("mkdir -p /mnt/hidpart/Data/apps/wsysrt/opt/wsysrt/")
#	os.system("[ ! -e /mnt/hidpart/Data/apps/wsysrt/opt/wsysrt/Password.ini ] && cp /opt/wsysrt/Password.ini /mnt/hidpart/Data/apps/wsysrt/opt/wsysrt/")
	gettext.bindtextdomain(APP_NAME, "./po")
	gettext.textdomain(APP_NAME)
	_ = gettext.gettext

	desktop_main_window = MainWindow()
	gtk.main()
