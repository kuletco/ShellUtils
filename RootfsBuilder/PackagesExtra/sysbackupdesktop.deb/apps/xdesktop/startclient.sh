#!/bin/sh

APPNAME=xdesktop
APPPATH=/apps/${APPNAME}

exec ${APPPATH}/bin/xdesktop $@
