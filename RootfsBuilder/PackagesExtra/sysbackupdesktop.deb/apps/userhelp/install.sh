#!/bin/sh

APPNAME=userhelp
APPPATH=/apps/${APPNAME}


