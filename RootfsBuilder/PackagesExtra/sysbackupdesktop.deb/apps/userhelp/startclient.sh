#!/bin/sh

APPNAME=userhelp
APPPATH=/apps/${APPNAME}

exec ${APPPATH}/bin/${APPNAME} $@

