#!/bin/sh

APPNAME=sysbackup
APPPATH=/apps/${APPNAME}

exec ${APPPATH}/bin/${APPNAME} $@

