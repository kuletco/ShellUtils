#!/bin/sh

APPNAME=sysbackup
APPPATH=/apps/${APPNAME}


