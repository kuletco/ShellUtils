#!/usr/bin/env python
# -*- coding:utf-8 -*-
# pylint: disable=too-many-instance-attributes,too-many-public-methods,no-self-use,consider-iterating-dictionary

import os
import time
import json
import commands
import subprocess
import threading
import uuid
import gtk
import gobject

(
    COLUMN_FIXED,
    COLUMN_DESCRIPTION
) = range(2)

DEBUG = True
DEBUG_TRACKER = False

DISKS = {}
DISKLIST = []

SYSBACKUP_PWD = os.path.dirname(os.path.abspath(__file__))
MAIN_UI_GLADE_FILE = os.path.join(SYSBACKUP_PWD, 'res/sysbackup.glade')

#### Misc Functions
def _print(mtype, message):
    if not isinstance(mtype, str):
        return
    if mtype.lower() == 'output':
        print str(message)
    elif DEBUG and mtype.lower() == 'debug':
        print "DEBUG:", str(message)
    elif DEBUG and DEBUG_TRACKER and mtype.lower() == 'tracker':
        print "FUNCTION:", str(message)
    elif mtype.lower() != 'debug' and mtype.lower() != 'tracker':
        print "%s: %s" % (mtype.upper(), str(message))

def bytes2human(size):
    symbols = ('KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB')
    prefix = {}
    ssize = int(size)
    for i, symbol in enumerate(symbols):
        prefix[symbol] = 1 << (i + 1) * 10
    for symbol in reversed(symbols):
        if ssize >= prefix[symbol]:
            value = float(ssize) / prefix[symbol]
            return '%.2f %s' % (value, symbol)
    return '%s Bytes' % size

def build_storage_info():
    # (status, output) = commands.getstatusoutput('lsblk -b -O -J')
    (status, output) = commands.getstatusoutput('lsblk -b -J -o "NAME,FSTYPE,MOUNTPOINT,LABEL,UUID,RO,RM,MODEL,SIZE,TYPE,STATE"')
    if status != 0:
        return False

    blks = json.loads(output)
    if not blks.has_key('blockdevices'):
        _print('ERROR', "Invalid Json format output")
        _print('OUTPUT', blks)
        return False

    for blkdev in blks['blockdevices']:
        if blkdev['type'] != 'disk':
            continue
        _print('DEBUG', "Block Dev: %s '%s' Type: '%s' Size: '%s'" % (blkdev['name'], blkdev['model'], blkdev['type'], bytes2human(blkdev['size'])))
        DISKLIST.append(blkdev['name'])
        DISKS[blkdev['name']] = blkdev
        DISKS[blkdev['name']]['partlist'] = []
        blkdev['desc'] = 'Disk %d [%s] %s' % (len(DISKS), blkdev['model'], bytes2human(blkdev['size']))
        if blkdev['rm'] == '1':
            blkdev['desc'] = blkdev['desc'] + ' (Removable)'
        if blkdev.has_key('children'):
            children = {}
            while blkdev['children']:
                child = blkdev['children'].pop(0)
                children[child['name']] = child
                DISKS[blkdev['name']]['partlist'].append(child['name'])
            DISKS[blkdev['name']]['partlist'].sort()

            DISKS[blkdev['name']].pop('children')
            DISKS[blkdev['name']]['children'] = children
        else:
            DISKS[blkdev['name']]['children'] = {}
    DISKLIST.sort()

    return True

def get_wim_image_counts(wimfile):
    image_counts = 0
    _print('DEBUG', 'WimFile: %s' % wimfile)
    if wimfile is None or wimfile == '':
        return image_counts
    (status, output) = commands.getstatusoutput('wiminfo %s --header' % wimfile)
    if status != 0:
        _print('ERROR', 'Get Wim Information failed!\n%s' % output)
        return image_counts
    lines = output.splitlines()
    for line in lines:
        if line.find('=') == -1:
            continue
        if line.strip().startswith('Image Count'):
            image_counts = int(line.split('=')[1].strip())
            break
    return image_counts

def build_wim_image_info(wimfile):
    count = get_wim_image_counts(wimfile)
    images = []
    for index in range(1, count + 1):
        (status, output) = commands.getstatusoutput('wiminfo %s %d' % (wimfile, index))
        if status != 0:
            _print('ERROR', 'Cannot get image info from wimfile: %s\n%s' % (wimfile, output))
            return images
        image = {}
        lines = output.splitlines()
        for line in lines:
            if line.find(':') == -1:
                continue
            items = line.split(':', 1)
            image[items[0].strip()] = items[1].strip()
        images.append(image)
    return images

#### Signal Connectors
# { widget : { signal : (before=False|after=True, handler_id) }}
G_HANDLER_IDS = {}

def signal_connect(builder, widget_name, signal, handler, data=None):
    widget = builder.get_object(widget_name)
    # key = str(widget)
    key = widget_name
    if G_HANDLER_IDS.has_key(key) and G_HANDLER_IDS[key].has_key(signal):
        return G_HANDLER_IDS[key][signal][1]
    if data is None:
        handler_id = widget.connect(signal, handler)
    else:
        handler_id = widget.connect(signal, handler, data)
    if not G_HANDLER_IDS.has_key(key):
        G_HANDLER_IDS[key] = {}
    G_HANDLER_IDS[key][signal] = (False, handler_id)
    return handler_id

def signal_connect_after(builder, widget_name, signal, handler, data=None):
    widget = builder.get_object(widget_name)
    # key = str(widget)
    key = widget_name
    if G_HANDLER_IDS.has_key(key) and G_HANDLER_IDS[key].has_key(signal):
        return G_HANDLER_IDS[key][signal][1]
    if data is None:
        handler_id = widget.connect_after(signal, handler)
    else:
        handler_id = widget.connect_after(signal, handler, data)
    if not G_HANDLER_IDS.has_key(key):
        G_HANDLER_IDS[key] = {}
    G_HANDLER_IDS[key][signal] = (True, handler_id)
    return handler_id

def signal_disconnect(builder, widget_name, signal=None, after=False):
    widget = builder.get_object(widget_name)
    # key = str(widget)
    key = widget_name
    if signal is None:
        if G_HANDLER_IDS.has_key(key):
            while G_HANDLER_IDS[key]:
                signal, (is_after, handler_id) = G_HANDLER_IDS[key].popitem()
                if is_after == after:
                    widget.disconnect(handler_id)
    else:
        if G_HANDLER_IDS.has_key(key) and G_HANDLER_IDS[key].has_key(signal):
            is_after, handler_id = G_HANDLER_IDS[key].pop(signal)
            if is_after == after:
                widget.disconnect(handler_id)

def signal_disconnect_all(builder):
    if G_HANDLER_IDS:
        for key in G_HANDLER_IDS.keys():
            signal_disconnect(builder, key)
            signal_disconnect(builder, key, after=True)
    G_HANDLER_IDS.clear()

class BackupAndRestore():
    def __init__(self):
        _print('TRACKER', '__init__')
        # Init Data Structs
        self.on_workding = False

        self.clear_datas()

        # Init Disks Info
        if build_storage_info() is not True:
            _print('Error', "Get system storage information failed!")
            exit(1)

        self.init_mainwindow()

    def init_mainwindow(self):
        _print('TRACKER', 'init_mainwindow')
        # Init UI Widgets
        self.gladefile = MAIN_UI_GLADE_FILE
        self.builder = gtk.Builder()
        self.builder.add_from_file(self.gladefile)
        self.builder.connect_signals(self)

        # Main Window
        self.window = self.builder.get_object("main_app")
        self.window.connect("destroy", gtk.main_quit)
        self.window.show()

        # Main Tables
        self.main_tabs = self.builder.get_object("main_tabs")
        self.main_tabs.connect_after("switch-page", self.on_main_tabs_switch_page)
        self.main_tabs.set_show_tabs(False)

        self.init_welcome_frame()
        self.init_backup_frame()
        self.init_restore_frame()

    def init_welcome_frame(self):
        _print('TRACKER', 'init_welcome_frame')
        self.welcome_button_backup = self.builder.get_object("welcome_button_backup")
        self.welcome_button_restore = self.builder.get_object("welcome_button_restore")

        self.welcome_button_backup.connect("clicked", self.on_welcome_button_backup_clicked)
        self.welcome_button_restore.connect("clicked", self.on_welcome_button_restore_clicked)

    def init_backup_frame(self):
        _print('TRACKER', 'init_backup_frame')
        # Backup main box
        self.backup_tabs = self.builder.get_object("backup_tabs")
        self.backup_tabs.set_show_tabs(False)
        # Backup Cancel, Previous, Next buttons
        self.backup_button_cancel = self.builder.get_object("backup_button_cancel")
        self.backup_button_prev = self.builder.get_object("backup_button_prev")
        self.backup_button_next = self.builder.get_object("backup_button_next")
        # Backup Source Disks
        self.backup_source_disks = self.builder.get_object("backup_source_disks")               # Combobox
        self.backup_source_disks_cell = self.builder.get_object("backup_source_disks_cell")     # Combobox CellRendererText
        self.backup_source_disks_store = self.builder.get_object("backup_source_disks_store")   # Combobox ListStore
        # Backup Source Parts
        self.backup_source_parts = self.builder.get_object("backup_source_parts")                           # TreeView
        self.backup_source_parts_save_column = self.builder.get_object("backup_source_parts_save_column")   # TreeViewColumn
        self.backup_source_parts_desc_column = self.builder.get_object("backup_source_parts_desc_column")   # TreeViewColumn
        self.backup_source_parts_save_cell = self.builder.get_object("backup_source_parts_save_cell")       # TreeView CellrendererToggle
        self.backup_source_parts_desc_cell = self.builder.get_object("backup_source_parts_desc_cell")       # TreeView CellrendererText
        self.backup_source_parts_store = self.builder.get_object("backup_source_parts_store")               # TreeView ListStore
        # Backup Destination Device
        self.backup_destination = self.builder.get_object("backup_destination")                 # Combobox
        self.backup_destination_cell = self.builder.get_object("backup_destination_cell")       # Combobox CellrendererText
        self.backup_destinations_store = self.builder.get_object("backup_destinations_store")   # Combobox ListStore
        # Backup Destination Folder
        self.backup_folder = self.builder.get_object("backup_folder")
        self.backup_folder_browse = self.builder.get_object("backup_folder_browse")
        # Backup Destination Detail
        self.backup_name = self.builder.get_object("backup_name")
        # Backup Progress & Status
        self.backup_progress = self.builder.get_object("backup_progress")
        self.backup_progress_status = self.builder.get_object("backup_progress_status")

    def init_restore_frame(self):
        _print('TRACKER', 'init_restore_frame')
        # Restore main box
        self.restore_tabs = self.builder.get_object("restore_tabs")
        self.restore_tabs.set_show_tabs(False)
        # Restore Cancel, Previous, Next buttons
        self.restore_button_cancel = self.builder.get_object("restore_button_cancel")
        self.restore_button_prev = self.builder.get_object("restore_button_prev")
        self.restore_button_next = self.builder.get_object("restore_button_next")
        # Restore Source Partition
        self.restore_source_part = self.builder.get_object("restore_source_part")               # Combobox
        self.restore_source_part_cell = self.builder.get_object("restore_source_part_cell")     # Combobox CellRendererText
        self.restore_source_part_store = self.builder.get_object("restore_source_part_store")   # Combobox ListStore
        # Restore Source File
        self.restore_source_image_file = self.builder.get_object("restore_source_image_file")       # FileChooser
        self.restore_source_images = self.builder.get_object("restore_source_images")               # Combobox
        self.restore_source_images_cell = self.builder.get_object("restore_source_images_cell")     # Combobox CellRendererText
        self.restore_source_images_store = self.builder.get_object("restore_source_images_store")   # Combobox ListStore
        # Restore Destination
        self.restore_destination = self.builder.get_object("restore_destination")               # Combobox
        self.restore_destination_cell = self.builder.get_object("restore_destination_cell")     # Combobox CellRendererText
        self.restore_destination_store = self.builder.get_object("restore_destination_store")   # Combobox ListStore
        # Restore Progress & Status
        self.restore_progress = self.builder.get_object("restore_progress")
        self.restore_progress_status = self.builder.get_object("restore_progress_status")

    ######### Public UI Functions #########
    def set_main_title(self, title):
        _print('TRACKER', 'set_main_title')
        self.main_title = self.builder.get_object("main_title")
        self.main_title.set_label(title)

    def clear_datas(self):
        _print('TRACKER', 'clear_datas')
        # Backup
        self.backup_src_disk = ''
        self.backup_src_partlist = []
        self.backup_dst_disk = ''
        self.backup_dst_part = ''
        self.backup_dst_path = ''
        self.backup_dst_files = {}
        self.backup_descs = {}
        # Restore
        self.restore_partlist = []
        self.restore_src_disk = ''
        self.restore_src_part = ''
        self.restore_src_path = ''
        self.restore_src_file = ''
        self.restore_src_image_index = 0
        self.restore_dst_disk = ''
        self.restore_dst_part = ''

    def clear_ui_datas(self):
        _print('TRACKER', 'clear_ui_datas')
        # Backup
        self.backup_button_prev.set_sensitive(False)
        self.backup_button_next.set_sensitive(False)
        self.backup_source_parts.set_sensitive(False)
        self.backup_folder.set_sensitive(False)
        self.backup_folder_browse.set_sensitive(False)
        self.backup_name.set_sensitive(False)
        self.backup_source_disks_store.clear()
        self.backup_source_parts_store.clear()
        self.backup_destinations_store.clear()
        # Restore
        self.restore_button_prev.set_sensitive(False)
        self.restore_button_next.set_sensitive(False)
        self.restore_source_image_file.set_sensitive(False)
        self.restore_source_images.set_sensitive(False)
        self.restore_source_part_store.clear()
        self.restore_source_images_store.clear()
        self.restore_destination_store.clear()

    def clear_connections(self):
        _print('TRACKER', 'clear_connections')
        signal_disconnect_all(self.builder)

    def pop_modal_dialog(self, msgtype, message):
        message_type = gtk.MESSAGE_INFO
        msgtype = msgtype.upper()
        if isinstance(msgtype, str):
            if msgtype == 'INFO':
                message_type = gtk.MESSAGE_INFO
            elif msgtype == 'WARNING':
                message_type = gtk.MESSAGE_INFO
            elif msgtype == 'QUESTION':
                message_type = gtk.MESSAGE_QUESTION
            else:
                message_type = gtk.MESSAGE_ERROR

        dialog = gtk.MessageDialog(self.window, gtk.DIALOG_MODAL, message_type, (gtk.BUTTONS_OK), message)
        dialog.run()
        dialog.destroy()

    ######### Backup #########
    def backup_signals_connector(self, page):
        _print('TRACKER', 'backup_signals_connector')
        if page == 0:
            signal_disconnect(self.builder, 'backup_destination', 'changed')
            signal_disconnect(self.builder, 'backup_folder_browse', 'clicked')
            signal_connect(self.builder, 'backup_source_disks', 'changed', self.on_backup_source_disk_changed)
            signal_connect(self.builder, 'backup_source_parts_save_cell', 'toggled', self.on_backup_source_partitions_cell_save_toggled, self.backup_source_parts_store)
        elif page == 1:
            signal_disconnect(self.builder, 'backup_source_disks', 'changed')
            signal_disconnect(self.builder, 'backup_source_parts_save_cell', 'toggled')
            signal_connect(self.builder, 'backup_destination', 'changed', self.on_backup_destination_changed)
            signal_connect(self.builder, 'backup_folder_browse', 'clicked', self.on_backup_folder_browse_clicked)
        # elif page == 2:

    def backup_build_source_disklist(self, force=False):
        _print('TRACKER', 'backup_build_source_disklist')
        self.backup_source_disks_store.clear()
        _print('DEBUG', "BackDisks [%d devices]:" % len(DISKLIST))
        for disk in DISKLIST:
            if not DISKS[disk]['children']:
                continue
            _print('DEBUG', " Disk: %s %s %s" % (disk, bytes2human(DISKS[disk]['size']), str(DISKS[disk]['partlist'])))
            # ListStore [ Description | Disk ]
            self.backup_source_disks_store.append([DISKS[disk]['desc'], disk])

    def backup_build_source_partlist(self, force=False):
        _print('TRACKER', 'backup_build_source_partlist')
        self.backup_src_partlist = []
        self.backup_source_parts_store.clear()
        diskindex = DISKLIST.index(self.backup_src_disk)
        partlist = DISKS[self.backup_src_disk]['partlist']
        children = DISKS[self.backup_src_disk]['children']
        for part in partlist:
            child = children[part]
            desc = 'Disk %d Part %s : (%s %s)' % (diskindex + 1, child['name'][-1], bytes2human(child['size']), child['fstype'])
            self.backup_src_partlist.append(part)
            # ListStore [ Save | Description | Disk | Driver(Partition) ]
            self.backup_source_parts_store.append([True, desc, self.backup_src_disk, part])

        _print('DEBUG', "BackParts: %s" % self.backup_src_partlist)

        if self.backup_src_partlist:
            self.backup_button_next.set_sensitive(True)
            self.backup_source_parts.set_sensitive(True)
        else:
            _print('Warning', 'Backup Disk doesnot contain a valid partition!')

    def backup_build_destination_list(self, force=False):
        _print('TRACKER', 'backup_build_destination_list')
        if self.backup_dst_disk is not None and self.backup_dst_disk != '':
            return
        self.backup_destinations_store.clear()
        for disk in DISKLIST:
            diskindex = DISKLIST.index(disk)
            if disk == self.backup_src_disk:
                continue

            diskinfo = DISKS[disk]
            partlist = diskinfo['partlist']
            diskremovable = ''
            if diskinfo['rm'] == 1:
                diskremovable = ' (Removable)'

            for part in partlist:
                partindex = partlist.index(part)
                child = diskinfo['children'][part]
                label = ''
                if child['label'] is not None and child['label'] != 'None':
                    label = child['label']
                mountpoint = ''
                if child['mountpoint'] is not None and child['mountpoint'] != 'None':
                    mountpoint = ' ' + child['mountpoint']
                fstype = child['fstype']
                desc = ''
                desc = desc + ('Disk %d' % diskindex) + diskremovable + ' '
                desc = desc + ('Partition %d: %s( %s %s%s )' % (partindex + 1, label, bytes2human(child['size']), fstype, mountpoint))
                _print('DEBUG', 'DescList: %s' % desc)
                # ListStore [ Description | Disk | Partition | FS Type | MountPoint ]
                self.backup_destinations_store.append([desc, disk, part, fstype, child['mountpoint']])

    def backup_start(self):
        _print('TRACKER', 'backup_start')
        self.on_workding = True
        self.backup_button_cancel.set_label("Stop")
        self.do_backup_start()

    def backup_stop(self):
        _print('TRACKER', 'backup_stop')
        self.on_workding = False

    def backup_failed(self, status=0):
        _print('TRACKER', 'backup_failed')
        self.on_workding = False
        self.backup_button_cancel.set_label("Cancel")
        self.backup_button_prev.set_sensitive(True)

    def backup_finished(self):
        _print('TRACKER', 'backup_finished')
        self.on_workding = False
        self.backup_button_cancel.set_label("Finish")
        self.backup_button_prev.set_sensitive(False)
        self.backup_button_next.set_sensitive(False)
        # self.pop_modal_dialog('INFO', 'Backup %s finished!' % self.restore_dst_disk)

    ######### Restore #########
    def restore_signals_connector(self, page):
        _print('TRACKER', 'restore_signals_connector')
        if page == 0:
            signal_disconnect(self.builder, 'restore_destination', 'changed')
            signal_connect(self.builder, 'restore_source_part', 'changed', self.on_restore_source_part_changed)
            signal_connect(self.builder, 'restore_source_image_file', 'file-set', self.on_restore_source_image_file_selected)
            signal_connect(self.builder, 'restore_source_images', 'changed', self.on_restore_source_images_changed)
        elif page == 1:
            signal_disconnect(self.builder, 'restore_source_part', 'changed')
            signal_disconnect(self.builder, 'restore_source_image_file', 'file-set')
            signal_disconnect(self.builder, 'restore_source_images', 'changed')
            signal_connect(self.builder, 'restore_destination', 'changed', self.on_restore_destination_changed)
        # elif page == 2:

    def restore_build_source_partlist(self, force=False):
        _print('TRACKER', 'restore_build_source_partlist')
        self.restore_source_part_store.clear()
        for disk in DISKLIST:
            diskindex = DISKLIST.index(disk)
            for part in DISKS[disk]['partlist']:
                partindex = DISKS[disk]['partlist'].index(part)
                mountpoint = DISKS[disk]['children'][part]['mountpoint']
                fstype = DISKS[disk]['children'][part]['fstype']
                if mountpoint is None or mountpoint == '' or fstype == 'swap':
                    continue
                desc = 'Disk %d' % diskindex
                if DISKS[disk]['rm'] == '1':
                    desc = desc = ' (Removable)'
                desc = desc + ' - Partition %d - %s' % (partindex, mountpoint)
                _print('DEBUG', "Source Partition: %s" % desc)
                # ListStore [ Description | Disk | Partition | MountPoint ]
                self.restore_source_part_store.append([desc, disk, part, mountpoint])

    def restore_build_source_imagelist(self, force=False):
        _print('TRACKER', 'restore_build_source_imagelist')
        images_info = build_wim_image_info(self.restore_src_file)
        self.restore_source_images_store.clear()
        for image in images_info:
            # ListStore [ Image Name | index ]
            self.restore_source_images_store.append([image['Name'], int(image['Index'])])

    def restore_build_destination_list(self, force=False):
        _print('TRACKER', 'restore_build_destination_list')
        self.restore_destination_store.clear()
        for disk in DISKLIST:
            diskindex = DISKLIST.index(disk)
            for part in DISKS[disk]['partlist']:
                if part == self.restore_src_part:
                    continue
                partindex = DISKS[disk]['partlist'].index(part)
                fstype = DISKS[disk]['children'][part]['fstype']
                desc = 'Disk %d' % diskindex
                if DISKS[disk]['rm'] == '1':
                    desc = desc = ' (Removable)'
                desc = desc + ' - Partition %d - %s' % (partindex, fstype)
                _print('DEBUG', "Destination Partition: %s" % desc)
                # ListStore [ Description | Disk | Partition | FS Type ]
                self.restore_destination_store.append([desc, disk, part, fstype])

    def restore_start(self):
        _print('TRACKER', 'restore_start')
        self.on_workding = True
        self.restore_button_cancel.set_label("Stop")
        self.do_restore_start()

    def restore_stop(self):
        _print('TRACKER', 'restore_stop')
        self.on_workding = False

    def restore_failed(self, status=0):
        _print('TRACKER', 'restore_failed')
        self.on_workding = False
        self.restore_button_cancel.set_label("Cancel")
        self.restore_button_prev.set_sensitive(True)

    def restore_finished(self):
        _print('TRACKER', 'restore_finished')
        self.on_workding = False
        self.restore_button_cancel.set_label("Finish")
        self.restore_button_prev.set_sensitive(False)
        self.restore_button_next.set_sensitive(False)
        # self.pop_modal_dialog('INFO', 'Restore %s finished!' % self.restore_dst_part)

    # ======================== Callbacks ======================== #
    ######### Main Window #########
    def on_main_tabs_switch_page(self, widget, obj, page):
        _print('TRACKER', 'on_main_tabs_switch_page: %d' % page)
        if page == 0:
            self.set_main_title("Welcome")
            self.clear_connections()
            self.clear_ui_datas()
            self.clear_datas()
        elif page == 1:
            self.set_main_title("Backup")
            self.backup_button_prev.set_sensitive(False)
            self.backup_button_next.set_sensitive(False)
            self.backup_source_parts.set_sensitive(False)
            self.backup_signals_connector(0)

            signal_connect(self.builder, 'backup_button_cancel', 'clicked', self.on_backup_button_cancel_clicked)
            signal_connect(self.builder, 'backup_button_prev', 'clicked', self.on_backup_button_prev_clicked)
            signal_connect(self.builder, 'backup_button_next', 'clicked', self.on_backup_button_next_clicked)
            signal_connect_after(self.builder, 'backup_tabs', 'switch-page', self.on_backup_tabs_switch_page)
        elif page == 2:
            self.set_main_title("Restore")
            self.restore_button_prev.set_sensitive(False)
            self.restore_button_next.set_sensitive(False)
            self.restore_source_image_file.set_sensitive(False)
            self.restore_source_images.set_sensitive(False)
            self.restore_signals_connector(0)

            signal_connect(self.builder, 'restore_button_cancel', 'clicked', self.on_restore_button_cancel_clicked)
            signal_connect(self.builder, 'restore_button_prev', 'clicked', self.on_restore_button_prev_clicked)
            signal_connect(self.builder, 'restore_button_next', 'clicked', self.on_restore_button_next_clicked)
            signal_connect_after(self.builder, 'restore_tabs', 'switch-page', self.on_restore_tabs_switch_page)
        else:
            _print("Error", "Invalid Page!")

    ######### Welcome #########
    def on_welcome_button_backup_clicked(self, widget):
        _print('TRACKER', 'on_welcome_button_backup_clicked')
        self.main_tabs.set_current_page(1)
        self.backup_tabs.set_current_page(0)

        self.backup_build_source_disklist()

    def on_welcome_button_restore_clicked(self, widget):
        _print('TRACKER', 'on_welcome_button_restore_clicked')
        self.main_tabs.set_current_page(2)
        self.restore_tabs.set_current_page(0)

        self.restore_build_source_partlist()

    ######### Backup #########
    def on_backup_tabs_switch_page(self, widget, obj, page):
        _print('TRACKER', 'on_backup_tabs_switch_page: %d %d' % (page, self.backup_tabs.get_current_page()))
        self.backup_signals_connector(page)
        if page == 0:
            self.backup_button_prev.set_sensitive(False)
            self.backup_button_next.set_label("Next >")
        elif page == 1:
            self.backup_button_prev.set_sensitive(True)
            self.backup_button_next.set_sensitive(True)
            self.backup_button_next.set_label("Start")
            self.backup_build_destination_list()
        elif page == 2:
            self.backup_button_prev.set_sensitive(False)
            self.backup_button_next.set_sensitive(False)
            self.backup_button_next.set_label("Stop")
            self.backup_start()
        else:
            _print("Error", "Invalid Page!")

    def on_backup_button_cancel_clicked(self, widget):
        _print('TRACKER', 'on_backup_button_cancel_clicked')
        if self.backup_tabs.get_current_page() == 2 and self.on_workding:
            self.backup_stop()
            self.backup_button_cancel.set_label("Cancel")
            self.backup_button_prev.set_sensitive(True)
        else:
            self.main_tabs.set_current_page(0)
            self.backup_tabs.set_current_page(0)

    def on_backup_button_prev_clicked(self, widget):
        _print('TRACKER', 'on_backup_button_prev_clicked')
        self.backup_button_next.set_sensitive(True)
        self.backup_tabs.prev_page()

    def on_backup_button_next_clicked(self, widget):
        _print('TRACKER', 'on_backup_button_next_clicked')
        self.backup_button_next.set_sensitive(False)
        self.backup_tabs.next_page()

    def on_backup_source_disk_changed(self, widget):
        _print('TRACKER', 'on_backup_source_disk_changed')
        index = self.backup_source_disks.get_active()
        if len(DISKS) > index:
            self.backup_src_disk = DISKLIST[index]
            self.backup_build_source_partlist()
        else:
            self.backup_src_disk = ''
            self.backup_source_parts.set_sensitive(False)
        self.backup_dst_disk = ''

    def on_backup_source_partitions_cell_save_toggled(self, cell, path, model):
        _print('TRACKER', 'on_backup_source_partitions_cell_save_toggled: %s' % path)
        active_iter = model.get_iter((int(path),))
        if active_iter is None:
            return
        # model: ListStore [ Save | Description | Disk | Driver(Partition) ]
        save = not model.get_value(active_iter, 0)
        part = model.get_value(active_iter, 3)
        model.set(active_iter, 0, save)

        if save:
            self.backup_src_partlist.append(part)
        else:
            self.backup_src_partlist.remove(part)

        if self.backup_src_partlist:
            self.backup_button_next.set_sensitive(True)
        else:
            self.backup_button_next.set_sensitive(False)

        self.backup_dst_part = ''

        _print('DEBUG', "BackParts: %s" % str(self.backup_src_partlist))

    def on_backup_destination_changed(self, widget):
        _print('TRACKER', 'on_backup_destination_changed')
        model = widget.get_model()
        active_iter = widget.get_active_iter()
        if active_iter is None:
            return

        # model: ListStore [ Description | Disk | Partition | FS Type | MountPoint ]
        fstype = model.get_value(active_iter, 3)
        mountpoint = model.get_value(active_iter, 4)

        self.backup_dst_disk = model.get_value(active_iter, 1)
        self.backup_dst_part = model.get_value(active_iter, 2)
        _print('DEBUG', "Backup destination partition: %s" % self.backup_dst_part)

        if self.backup_dst_disk is None or self.backup_dst_disk == '':
            self.backup_build_destination_list()

        if not (mountpoint == '' or fstype == 'swap'):
            self.backup_dst_path = "%s/%s" % (mountpoint, "BackUp-%s" % time.strftime("%Y-%m-%d", time.localtime()))
            _print('DEBUG', "Backup destination directory: %s" % self.backup_dst_path)
            if not os.path.exists(self.backup_dst_path):
                os.makedirs(self.backup_dst_path, 0755)

            self.backup_dst_files.clear()
            destfiles_str = ''
            for part in self.backup_src_partlist:
                timestring = time.strftime("%Y-%m-%d-%H:%M", time.localtime())
                destfile = "%s-%s.wim" % (part, time.strftime("%Y-%m-%d-%H.%M", time.localtime()))
                self.backup_descs[part] = {}
                self.backup_descs[part]['label'] = "%s - %s" % (part, timestring)
                self.backup_descs[part]['desc'] = "Backup %s at %s" % (part, timestring)
                self.backup_dst_files[part] = destfile
                if destfiles_str == '':
                    destfiles_str = destfile
                else:
                    destfiles_str = "%s, %s" % (destfiles_str, destfile)
            destfiles_str = "%s/[%s]" % (self.backup_dst_path, destfiles_str)
            _print('DEBUG', "Backup destination file: %s" % destfiles_str)

            self.backup_folder.set_text(self.backup_dst_path)
            self.backup_name.set_text(destfiles_str)
            self.backup_folder.set_sensitive(True)
            self.backup_folder_browse.set_sensitive(True)
            self.backup_name.set_sensitive(True)
            self.backup_button_next.set_sensitive(True)
        else:
            self.backup_folder.set_text("")
            self.backup_name.set_text("")
            self.backup_folder.set_sensitive(False)
            self.backup_folder_browse.set_sensitive(False)
            self.backup_name.set_sensitive(False)
            self.backup_button_next.set_sensitive(False)

    def on_backup_folder_browse_clicked(self, widget):
        _print('TRACKER', 'on_backup_folder_browse_clicked')
        dest_mountpoint = DISKS[self.backup_dst_disk]['children'][self.backup_dst_part]['mountpoint']

        filechooser = gtk.FileChooserDialog("Select a folder", self.window, gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER)
        filechooser.add_button(gtk.STOCK_OPEN, gtk.RESPONSE_ACCEPT)
        filechooser.set_current_folder(dest_mountpoint)
        if filechooser.run() == gtk.RESPONSE_ACCEPT:
            self.backup_dst_path = filechooser.get_filename()
            if self.backup_dst_path is None:
                self.backup_dst_path = filechooser.get_current_folder()
        else:
            self.backup_dst_path = dest_mountpoint
        filechooser.destroy()

    def on_backup_stopped(self, status=0, data=None):
        _print('TRACKER', 'on_backup_stopped')
        if status == 0:
            self.backup_finished()
        else:
            self.backup_failed(status)

    ######### Restore #########
    def on_restore_tabs_switch_page(self, widget, obj, page):
        _print('TRACKER', 'on_restore_tabs_switch_page: %d %d' % (page, self.restore_tabs.get_current_page()))
        self.restore_signals_connector(page)
        if page == 0:
            self.restore_button_prev.set_sensitive(False)
            self.restore_button_next.set_label("Next >")
        elif page == 1:
            self.restore_button_prev.set_sensitive(True)
            self.restore_button_next.set_sensitive(True)
            self.restore_button_next.set_label("Start")
            self.restore_build_destination_list()
        elif page == 2:
            self.restore_button_prev.set_sensitive(False)
            self.restore_button_next.set_sensitive(False)
            self.restore_start()
        else:
            _print("Error", "Invalid Page!")

    def on_restore_button_cancel_clicked(self, widget):
        _print('TRACKER', 'on_restore_button_cancel_clicked')
        if self.restore_tabs.get_current_page() == 2 and self.on_workding:
            self.restore_stop()
            self.restore_button_cancel.set_label("Cancel")
            self.restore_button_prev.set_sensitive(True)
        else:
            self.main_tabs.set_current_page(0)
            self.restore_tabs.set_current_page(0)

    def on_restore_button_prev_clicked(self, widget):
        _print('TRACKER', 'on_restore_button_prev_clicked')
        self.restore_button_next.set_sensitive(True)
        self.restore_tabs.prev_page()

    def on_restore_button_next_clicked(self, widget):
        _print('TRACKER', 'on_restore_button_next_clicked')
        self.restore_button_next.set_sensitive(False)
        self.restore_tabs.next_page()

    def on_restore_source_part_changed(self, widget):
        _print('TRACKER', 'on_backup_source_disk_changed')
        model = widget.get_model()
        active_iter = widget.get_active_iter()
        if active_iter is None:
            return

        # model: ListStore [ Description | Disk | Partition | MountPoint ]
        self.restore_src_disk = model.get_value(active_iter, 1)
        self.restore_src_part = model.get_value(active_iter, 2)
        self.restore_src_path = model.get_value(active_iter, 3)
        _print('DEBUG', "Restore source mount on: %s" % self.restore_src_path)

        self.restore_source_image_file.set_current_folder(self.restore_src_path)
        self.restore_source_image_file.set_sensitive(True)

    def on_restore_source_image_file_selected(self, widget, data=None):
        _print('TRACKER', 'on_restore_source_image_file_selected')
        self.restore_src_file = self.restore_source_image_file.get_filename()
        _print('DEBUG', 'Restore Image File: %s' % self.restore_src_file)
        if self.restore_src_file is None or self.restore_src_file == '':
            self.restore_source_images.set_sensitive(False)
        else:
            self.restore_source_images.set_sensitive(True)
            self.restore_build_source_imagelist()

    def on_restore_source_images_changed(self, widget):
        _print('TRACKER', 'on_restore_source_images_changed')
        model = widget.get_model()
        active_iter = widget.get_active_iter()
        if active_iter is None:
            return
        # model: ListStore [ Image Name | index ]
        self.restore_src_image_index = model.get_value(active_iter, 1)
        _print('DEBUG', 'Restore Image Index: %d' % self.restore_src_image_index)
        self.restore_button_next.set_sensitive(True)

    def on_restore_destination_changed(self, widget):
        _print('TRACKER', 'on_restore_destination_changed')
        model = widget.get_model()
        active_iter = widget.get_active_iter()
        if active_iter is None:
            return
        # model: ListStore [ Description | Disk | Partition | FS Type ]
        self.restore_dst_disk = model.get_value(active_iter, 1)
        self.restore_dst_part = model.get_value(active_iter, 2)
        _print('DEBUG', 'Restore Image Index: %d' % self.restore_src_image_index)
        self.restore_button_next.set_sensitive(True)

    def on_restore_stopped(self, status=0, data=None):
        _print('TRACKER', 'on_restore_stopped')
        if status == 0:
            self.restore_finished()
        else:
            self.restore_failed(status)

    # ======================== Callbacks End ======================== #

    # ======================== Backends ======================== #
    ######### Public Backends #########
    def do_command_in_thread(self, command, callback, callback_data=None):
        _print('TRACKER', 'do_command_in_thread')
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        while process.poll() is None:
            _print('DEBUG', 'ProcessLine: %s' % process.stdout.readline().strip())
        #     line = process.stdout.readline()
        #     _print('DEBUG', 'ProcessLine: %s' % line)
        #     time.sleep(0.5)
        process.communicate()
        process.wait()
        _print('DEBUG', 'Process: Command Finished %d' % process.returncode)
        if callback:
            _print('DEBUG', 'Process: Call Handler')
            gobject.idle_add(callback, process.returncode, callback_data)

    ######### Backup Backends #########
    def do_backup_start(self):
        _print('TRACKER', 'do_backup_start')
        for part in self.backup_src_partlist:
            mountpoint = DISKS[self.backup_src_disk]['children'][part]['mountpoint']
            fstype = DISKS[self.backup_src_disk]['children'][part]['fstype']
            destfile = "%s/%s" % (self.backup_dst_path, self.backup_dst_files[part])
            label = self.backup_descs[part]['label']
            desc = self.backup_descs[part]['desc']
            if fstype != 'ntfs':
                if mountpoint is None or mountpoint == '':
                    mountpoint = "/tmp/%s" % uuid.uuid1()
                    if not os.path.exists(mountpoint):
                        os.makedirs(mountpoint)
                    (status, output) = commands.getstatusoutput('mount /dev/%s %s' % (part, mountpoint))
                    if status != 0:
                        _print('ERROR', 'Cannot mount %s to a temp folder, please backup it manual.\n%s' % (part, output))
                        self.pop_modal_dialog('ERROR', 'Cannot mount %s to a temp folder, please backup it manual.\n%s' % (part, output))
                        self.backup_failed()
                        return
                self.do_backup_command(mountpoint, destfile, label, desc)
                # if mountpoint.startswith("/tmp/"):
                #     (status, output) = commands.getstatusoutput('umount %s' % mountpoint)
                #     if status != 0:
                #         _print('ERROR', 'Cannot unmount %s, please unmount it manual.\n%s' % (mountpoint, output))
                #         self.pop_modal_dialog('ERROR', 'Cannot unmount %s, please unmount it manual.\n%s' % (mountpoint, output))
            else:
                if not (mountpoint is None or mountpoint == ''):
                    _print('INFO', 'Backup unmount source device...')
                    (status, output) = commands.getstatusoutput('umount /dev/%s' % part)
                    if status != 0:
                        _print('ERROR', 'Cannot unmount %s, please unmount it manual and try again.\n%s' % (part, output))
                        self.pop_modal_dialog('ERROR', 'Cannot unmount %s, please unmount it manual and try again.\n%s' % (part, output))
                        self.backup_button_cancel.clicked()
                        self.backup_failed()
                        return
                self.do_backup_command("/dev/%s" % part, destfile, label, desc)

    def do_backup_command(self, source, dest, label, desc):
        _print('TRACKER', 'do_backup_command')
        # 01 umount source part
        # 02 'wimcapture/wimappend <source device/folder> <destination wim file> [label [description]] [options]
        # 03 recommand options: --solid
        command = 'wimappend "%s" "%s" "%s" "%s" --create' % (source, dest, label, desc)
        _print('DEBUG', "Backup Command: [%s]" % command)
        thread = threading.Thread(target=self.do_command_in_thread, args=(command, self.on_backup_stopped))
        thread.setDaemon(False)
        thread.start()
        # self.do_command_in_thread(command, self.on_backup_stopped)

    ######### Restore Backends #########
    def do_restore_start(self):
        _print('TRACKER', 'do_restore_start')
        mountpoint = DISKS[self.restore_dst_disk]['children'][self.restore_dst_part]['mountpoint']
        if not (mountpoint is None or mountpoint == ''):
            _print('WARNING', 'Restore need unmount destination partition')
            (status, output) = commands.getstatusoutput('umount /dev/%s' % self.restore_dst_part)
            if status != 0:
                _print('ERROR', 'Cannot unmount %s, please unmount it manual and try again.\n%s' % (self.restore_dst_part, output))
                self.pop_modal_dialog('ERROR', 'Cannot unmount %s, please unmount it manual and try again.\n%s' % (self.restore_dst_part, output))
                self.restore_button_cancel.clicked()
                self.restore_failed()
                return
        # FIXME: need run in thread
        (status, output) = commands.getstatusoutput('mkntfs /dev/%s' % self.restore_dst_part)
        if status != 0:
            _print('ERROR', 'Cannot unmount %s, please unmount it manual and try again.\n%s' % (self.restore_dst_part, output))
            self.pop_modal_dialog('ERROR', ' Cannot format %s, please format it manual and try again.\n%s' % (self.restore_dst_part, output))
            self.restore_button_cancel.clicked()
            self.restore_failed()
            return
        self.do_restore_command(self.restore_src_file, self.restore_src_image_index, '/dev/%s' % self.restore_dst_part)

    def do_restore_command(self, imagefile, index, dest):
        _print('TRACKER', 'do_restore_start')
        # 01 umount destination part
        # 02 'wimapply <source wim file> <image index> <destination device/part> [options]
        # 03 recommand options: --check
        command = 'wimapply "%s" "%s" "%s" --check' % (imagefile, index, dest)
        _print('DEBUG', "Backup Command: [%s]" % command)
        thread = threading.Thread(target=self.do_command_in_thread, args=(command, self.on_restore_stopped))
        thread.setDaemon(False)
        thread.start()
        # self.do_command_in_thread(command, self.on_restore_stopped)

    # ======================== Backends End ======================== #

if __name__ == "__main__":
    gtk.gdk.threads_init()
    BackupAndRestore()
    gtk.main()
